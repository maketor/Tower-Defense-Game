﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map_Controller : MonoBehaviour {

	public GameObject buildTile;
	public GameObject pathTile;

	public GameObject node;

	public List<GameObject> nodes;

	public static Map_Controller instance;

	// Use this for initialization
	void Awake () {

		instance = this;

		nodes = new List<GameObject> ();
		MakeDefaultMap ();
	}
	
	// Update is called once per frame
	void Update () {
		
	}


	void MakeDefaultMap () {

		for (int i = 0; i < 25; i++) {
			for (int j = 0; j < 25; j++) {

				if (i == 4 && j >= 10) {

					GameObject pathTileClone = Instantiate (pathTile, new Vector3 (i, j, 10f), Quaternion.identity);
					pathTileClone.transform.parent = this.transform;
					continue;
				}

				if (i == 21 && j <= 10) {

					GameObject pathTileClone = Instantiate (pathTile, new Vector3 (i, j, 10f), Quaternion.identity);
					pathTileClone.transform.parent = this.transform;
					continue;
				}

				if (j == 10 && (i > 4 && i < 21)) {

					GameObject pathTileClone = Instantiate (pathTile, new Vector3 (i, j, 10f), Quaternion.identity);
					pathTileClone.transform.parent = this.transform;
					continue;
				}

				GameObject buildTileClone = Instantiate (buildTile, new Vector3 (i, j, 10f), Quaternion.identity);
				buildTileClone.transform.parent = this.transform;
			}
		}

		//Place our nodes

		GameObject nodeClone = Instantiate (node, new Vector3 (4f, 26f, 0f), Quaternion.identity);
		nodeClone.transform.parent = this.transform;
		nodes.Add (nodeClone);

		nodeClone = Instantiate (node, new Vector3 (4f, 10f, 0f), Quaternion.identity);
		nodeClone.transform.parent = this.transform;
		nodes.Add (nodeClone);

		nodeClone = Instantiate (node, new Vector3 (21f, 10f, 0f), Quaternion.identity);
		nodeClone.transform.parent = this.transform;
		nodes.Add (nodeClone);

		nodeClone = Instantiate (node, new Vector3 (21f, -1f, 0f), Quaternion.identity);
		nodeClone.transform.parent = this.transform;
		nodes.Add (nodeClone);

	}
}
