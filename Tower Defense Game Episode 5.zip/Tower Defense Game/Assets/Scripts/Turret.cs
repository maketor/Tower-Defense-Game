﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret : MonoBehaviour {

	public float visionRadius;
	public float fireRate;
	public float rotateSpeed;

	public GameObject bullet;

	List<GameObject> enemiesInRadius;

	GameObject target;

	float time;

	// Use this for initialization
	void Start () {

		enemiesInRadius = new List<GameObject> ();

		CircleCollider2D collider = GetComponent <CircleCollider2D> ();
		collider.radius = visionRadius;
	}
	
	// Update is called once per frame
	void Update () {

		time += Time.deltaTime;

		if (enemiesInRadius.Count > 0 && target != null) {

			//Rotate towards the target
			//Degrees of rotation
			float targetAngle = Mathf.Atan2 (
				                transform.position.y - target.transform.position.y,
				                transform.position.x - target.transform.position.x
			) * Mathf.Rad2Deg;

			float nextAngle = Mathf.MoveTowardsAngle (transform.eulerAngles.z, targetAngle, Time.deltaTime * rotateSpeed);


			transform.eulerAngles = new Vector3 (
				0f, 
				0f, 
				nextAngle
			);

			//Check if we are at the correct angle
			if (IsNearTargetAngle (transform.eulerAngles.z, targetAngle, 5f)) {

				//Make sure enough time has passed to fire next bullet
				if (time >= fireRate) {

					GameObject bulletClone = Instantiate (bullet, transform.position, Quaternion.identity);
					Bullet bulletScript = bulletClone.GetComponent <Bullet> ();

					bulletScript.SetVelocityVectors (
						Mathf.Cos (targetAngle * Mathf.Deg2Rad) * -1f, 
						Mathf.Sin (targetAngle * Mathf.Deg2Rad) * -1f 
					);

					time = 0f;
				}
			}
		}

	}

	bool IsNearTargetAngle (float current, float target, float offset) {

		current = current % 360;
		target = target % 360;

		if (current < 0f)
			current += 360;

		if (target < 0f)
			target += 360;

		if (Mathf.Abs (target - current) <= offset)
			return true;
		return false;
	}

	void OnTriggerEnter2D (Collider2D collider) {

		if (enemiesInRadius.Count == 0)
			target = collider.gameObject;

		enemiesInRadius.Add (collider.gameObject);
	}

	void OnTriggerExit2D (Collider2D collider) {

		if (collider.gameObject.name.Contains ("Enemy")) {

			enemiesInRadius.Remove (collider.gameObject);

			if (enemiesInRadius.Count > 0) {

				target = enemiesInRadius [0];
			} else
				target = null;
		}


	}
}
