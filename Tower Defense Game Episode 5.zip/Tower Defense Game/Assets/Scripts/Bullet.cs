﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour {

	public float magnitude;

	Vector3 velocity;

	// Use this for initialization
	void Start () {
		
	}

	public void SetVelocityVectors (float x, float y) {

		velocity = new Vector3 (x * (Time.deltaTime / 2f), y * (Time.deltaTime / 2f), 0f) * magnitude;
	}

	// Update is called once per frame
	void Update () {

		transform.Translate (velocity);

		if (Mathf.Abs (transform.position.x) > 50f || Mathf.Abs (transform.position.y) > 50f)
			Destroy (this.gameObject);

	}
}
