﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy_Spawner : MonoBehaviour {

	public GameObject enemyPrefab;

	public bool playerReady;


	// Wave 1:  x x x 
	// Wave 2:  x x x x o
	// Wave 3: x o o o x x x

	int currentWave;

	Queue<GameObject> enemiesToSpawn;


	// Use this for initialization
	void Awake () {

		enemiesToSpawn = new Queue<GameObject> ();
		currentWave = 0;

		OnNextWave ();
	}
	
	// Update is called once per frame
	void Update () {

		if (playerReady == true && enemiesToSpawn.Count == 0) {

			currentWave++;
			OnNextWave ();
		}
	}

	void SpawnNextEnemy () {

		if (enemiesToSpawn.Count > 0) {

			GameObject enemyPrefab = enemiesToSpawn.Dequeue ();
			Instantiate (enemyPrefab);

			

		} else {

			CancelInvoke ();
		}
	}

	void OnNextWave () {

		if (currentWave == 0) {

			enemiesToSpawn.Enqueue (enemyPrefab);
			enemiesToSpawn.Enqueue (enemyPrefab);
			enemiesToSpawn.Enqueue (enemyPrefab);

			InvokeRepeating ("SpawnNextEnemy", 1.0f, 0.25f);

		}

		if (currentWave == 1) {

			enemiesToSpawn.Enqueue (enemyPrefab);
			enemiesToSpawn.Enqueue (enemyPrefab);
			enemiesToSpawn.Enqueue (enemyPrefab);
			enemiesToSpawn.Enqueue (enemyPrefab);
			enemiesToSpawn.Enqueue (enemyPrefab);
			enemiesToSpawn.Enqueue (enemyPrefab);
			enemiesToSpawn.Enqueue (enemyPrefab);

			InvokeRepeating ("SpawnNextEnemy", 1.0f, 0.25f);
		}


	}
}
