﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour {

	public float moveSpeed;
	public int health;

	int currentNode;
	Vector3 nextPosition;

	bool reachedEndOfMap;

	// Use this for initialization
	void Start () {

		if (health == 0)
			health = 5;

		reachedEndOfMap = false;

		currentNode = 0;
		GetNextNode (); //Give us the first node in the list
		transform.position = nextPosition; //Move to starting pos
		GetNextNode (); //Tells us first destination

	}
	
	// Update is called once per frame
	void Update () {

		if (reachedEndOfMap == true)
			return;

		Vector3 tempPosition = Vector3.MoveTowards (transform.position, nextPosition, Time.deltaTime * moveSpeed);
		tempPosition.z = transform.position.z;
		transform.position = tempPosition;


		if (nextPosition == transform.position) {

			GetNextNode ();
		}
	}

	void GetNextNode () {

		if (currentNode >= Map_Controller.instance.nodes.Count) {

			reachedEndOfMap = true;
			return;
		}


		GameObject current = Map_Controller.instance.nodes [currentNode];
		nextPosition = current.transform.position;
		currentNode++;

	}

	public void OnCollisionEnter2D (Collision2D collider) {

		if (collider.gameObject.name.Contains ("Bullet")) {


			health--;

			Destroy (collider.gameObject);

			if (health == 0) {
				Destroy (this.gameObject);
			}
		}
	}
}
